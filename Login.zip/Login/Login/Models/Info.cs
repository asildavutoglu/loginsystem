﻿namespace Login.Models
{
    public class Info
    {
        public int Id { get; set; }
        public string Mail { get; set; }

        public Info()
        {
            
        }
    }
}
